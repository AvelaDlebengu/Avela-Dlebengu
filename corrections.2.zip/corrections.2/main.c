#include <stdio.h>
#include <stdlib.h>

char menu();
void printAscii();
void quadratic(int a, int b, int c, int x);
void decimalToHex(int decimal);

int main() {
    char input;
    do {
        input = menu();
        switch (input) {
            case 'a':
                printAscii();
                break;
            case 'b': {
                int a, b, c, x;
                printf("Quadratic equation ax^2 + bx + c parameters\n");
                printf("Please enter the value of a: ");
                scanf("%d", &a);
                printf("Please enter the value of b: ");
                scanf("%d", &b);
                printf("Please enter the value of c: ");
                scanf("%d", &c);
                printf("Please enter the value of x: ");
                scanf("%d", &x);
                quadratic(a, b, c, x);
                break;
            }
            case 'c': {
                int decimal;
                printf("Please enter the decimal number: ");
                scanf("%d", &decimal);
                decimalToHex(decimal);
                break;
            }
            case 'x':
                printf("Good bye\nProgram done by Avela Dlebengu 240352432\n");
                break;
            default:
                printf("Wrong input selected\n");
        }
    } while (input != 'x');
    getchar();
    return 0;
}

char menu() {
    char input;
    printf("-------MENU--------\n");
    printf(" a: Print the Ascii table\n");
    printf(" b: Quadratic equation\n");
    printf(" c: Decimal to Hex\n");
    printf(" x: Exit\n");
    printf("Please choose an option: ");
    scanf(" %c", &input);
    return input;
}

void printAscii() {
    for (int i = 0; i <= 255; i++) {
        printf("%d ", i);
        printf("%c\n" ,i);
    }
}

void quadratic(int a, int b, int c, int x) {
    int result = a * x * x + b * x + c;
    printf("The result of %d * %d^2 + %d * %d + %d is %d\n", a, x, b, x, c, result);
}

void decimalToHex(int decimal) {
    printf("The hexadecimal representation is: %X\n", decimal);
}
