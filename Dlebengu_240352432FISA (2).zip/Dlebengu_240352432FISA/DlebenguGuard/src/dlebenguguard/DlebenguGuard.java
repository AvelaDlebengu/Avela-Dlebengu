package dlebenguguard;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;

public class DlebenguGuard extends JFrame {

    private JLabel label1;
    private JButton btn1, btn2;
    private char phase = '0';
    private String address = "No alarms";

    public static void main(String[] args) {
        new DlebenguGuard();
    }

    public DlebenguGuard() {
        super("Guard");

        label1 = new JLabel("Waiting for alarms...");
        btn1 = new JButton();
        btn2 = new JButton("Send backup");

        btn1.setVisible(false);
        btn2.setVisible(false);

        setLayout(new FlowLayout());
        add(label1);
        add(btn1);
        add(btn2);

        btn1.addActionListener(e -> handleBtn1());
        btn2.addActionListener(e -> sendAction("Send backup"));

        setSize(300, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);

        new Timer(3000, e -> connectToServer()).start();
    }

    private void connectToServer() {
        try (Socket socket = new Socket("localhost", 4321);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            out.println("Guard");
            String addr = in.readLine();
            out.println("No action");

            if (!addr.equals("No alarms")) {
                address = addr;
                label1.setText("Alarm at: " + address);
                updateButtons();
            } else {
                label1.setText("No alarms");
                btn1.setVisible(false);
                btn2.setVisible(false);
                phase = '0';
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void updateButtons() {
        btn1.setVisible(true);

        switch (phase) {
            case '0':
                btn1.setText("On my way");
                break;
            case '1':
                btn1.setText("Arrived");
                break;
            case '2':
                btn1.setText("Location safe");
                btn2.setVisible(true);
                break;
        }
    }

    private void handleBtn1() {
        switch (phase) {
            case '0':
                sendAction("Guard on his way");
                phase = '1';
                break;
            case '1':
                sendAction("Guard arrived");
                phase = '2';
                break;
            case '2':
                sendAction("House is save");
                btn1.setVisible(false);
                btn2.setVisible(false);
                phase = '0';
                break;
        }
        updateButtons();
    }

    private void sendAction(String action) {
        try (Socket socket = new Socket("localhost", 4321);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            out.println("Guard");
            out.println(action);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
