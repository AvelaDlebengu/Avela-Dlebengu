package dlebenguclienthome;
import javafx.application.Application;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.io.*;
import java.net.Socket;

public class DlebenguClientHome extends Application {

    private int step = 0;
    private boolean armed = false;
    private final String code = "132";

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        stage.setTitle("Home");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setVgap(10);
        grid.setHgap(10);

        TextField txtAddress = new TextField();
        txtAddress.setPromptText("Enter your address");
        grid.add(txtAddress, 0, 0, 2, 1);

        Label lblStatus = new Label("Alarm Disarmed");
        grid.add(lblStatus, 0, 1, 2, 1);

        Button btn1 = new Button("1");
        Button btn3 = new Button("3");
        Button btn2 = new Button("2");
        Button btnMove = new Button("Move");

        grid.add(btn1, 0, 2);
        grid.add(btn3, 1, 2);
        grid.add(btn2, 0, 3);
        grid.add(btnMove, 1, 3);

        btn1.setOnAction(e -> checkCode('1', lblStatus));
        btn3.setOnAction(e -> checkCode('3', lblStatus));
        btn2.setOnAction(e -> checkCode('2', lblStatus));

        btnMove.setOnAction(e -> {
            if (armed) {
                String houseAddress = txtAddress.getText().trim();
                if (houseAddress.isEmpty()) houseAddress = "Unknown Address";
                sendAlarm(houseAddress);
            }
        });

        Scene scene = new Scene(grid, 350, 250);
        stage.setScene(scene);
        stage.show();
    }

    private void checkCode(char digit, Label lbl) {
        if (digit == code.charAt(step)) {
            step++;
            if (step == code.length()) {
                armed = !armed;
                lbl.setText(armed ? "Alarm Armed" : "Alarm Disarmed");
                step = 0;
            }
        } else {
            step = 0;
        }
    }

    private void sendAlarm(String address) {
        try (Socket socket = new Socket("localhost", 4321);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            out.println("Home");
            out.println(address);

            System.out.println("Alarm sent for: " + address);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
