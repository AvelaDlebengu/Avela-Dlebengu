package dlebengucontrolroomserver;

import java.io.*;
import java.net.*;
import javax.swing.JOptionPane;

public class DlebenguControlRoomServer {

    private static boolean dispatch = false;
    private static String address = "No alarms";

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(4321)) {
            System.out.println("Control Room Server running on port 4321...");

            while (true) {
                Socket socket = serverSocket.accept();
                new Thread(() -> handleClient(socket)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleClient(Socket socket) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            String clientType = in.readLine();

           
            if ("Home".equalsIgnoreCase(clientType)) {
                address = in.readLine();

                if (!address.equalsIgnoreCase("No alarms")) {
                    System.out.println("\nALARM RECEIVED FROM: " + address);

                    int userIn = JOptionPane.showConfirmDialog(
                        null,
                        "Must a guard be dispatched to the client?",
                        "Dispatch Decision",
                        JOptionPane.YES_NO_CANCEL_OPTION
                    );

                    if (userIn == JOptionPane.YES_OPTION) {
                        dispatch = true;
                    } else {
                        dispatch = false;
                    }
                }
            }

            
            else if ("Guard".equalsIgnoreCase(clientType)) {

                if (dispatch) {
                    out.println(address);
                } else {
                    out.println("No alarms");
                }

                String guardAction = in.readLine();

                if (!guardAction.equalsIgnoreCase("No action")) {
                    System.out.println("GUARD UPDATE: " + guardAction);

                    if (guardAction.equalsIgnoreCase("House is save")) {
                        address = "No alarms";
                        dispatch = false;
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
